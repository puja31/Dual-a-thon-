# HealthCare

This is a login/register page created ussing Android Studio.
Authentication of the users is done using firebase.
This was primarily designed as a part of the hack that my team was going to build for Medi-Hackathon.
